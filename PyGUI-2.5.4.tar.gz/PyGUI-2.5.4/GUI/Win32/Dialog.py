#--------------------------------------------------------------------
#
#   PyGUI - Dialog - Win32
#
#--------------------------------------------------------------------

from GUI import export
from GUI.GDialogs import Dialog

export(Dialog)
