#
#   PyGUI - Edit command handling - Gtk
#

from GUI.GEditCmdHandlers import EditCmdHandler
