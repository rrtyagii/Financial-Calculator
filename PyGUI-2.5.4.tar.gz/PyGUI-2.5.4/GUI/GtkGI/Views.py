#
#   Python GUI - Views - Gtk
#

from GUI.GViews import View
